@include('includes.header')
@include('includes.navbar')
@include('includes.content')
@include('includes.footer')