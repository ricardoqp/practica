@extends('layouts.master')
@section('title', 'Repasito')

@section('header')
@parent
@stop

@section('navbar')
@parent
@stop

@section('content')
@parent
@stop

@section('footer')
@parent

@stop

