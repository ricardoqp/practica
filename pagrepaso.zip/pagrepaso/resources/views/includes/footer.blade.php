@section('footer')
<!-- Footer -->
<footer class="footer">

  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <p class="text-uppercase">Ricardo Quintana Pinedo 5°E</p>
        <p></p>

      </div>
     
    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  </footer>
</footer>
<!-- Footer -->
</body>
</html>
@show