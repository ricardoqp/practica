@section('content')
<div id="content" class="p-4 p-md-5 pt-5">
        <h2 class="mb-4">Pintores</h2>

        <p>Santiago, Allende, Montemorelos y cerramos en Terán, ¿Como ves bebecini?
        <br> <br>
        ¿Quieren ver mis tenis?, ¿qué tal?, fosfo, fosfo
        </p>

        <h2><center> fosfo, fosfo </center></h2>
        <h1><center> 👟 </center></h1>
       
      </div>
		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
@show